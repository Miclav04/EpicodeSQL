
-- CREATE DATABASE TOYSGROUP;

-- USE TOYSGROUP;


CREATE TABLE Product (
    ProductId INT PRIMARY KEY,
    Name_Product VARCHAR(100),
    Category VARCHAR(100)
);

CREATE TABLE Region (
    regionId INT PRIMARY KEY,
    Name_Region VARCHAR(255)
);

CREATE TABLE Sales (
    IdTransaction INT PRIMARY KEY,
    ProductId INT,
    regionId INT,
    OrderData DATE,
    UnitPrice DECIMAL(10, 2),
    FOREIGN KEY (ProductId) REFERENCES Product(ProductId),
    FOREIGN KEY (regionId) REFERENCES Region(regionId)
);





-- Inserimento dati
INSERT INTO Product (ProductId, Name_product, Category) 
VALUES
(1, 'Jenga', 'Giochi di abilità'),
(2, 'Barbie', 'Giocattolo'),
(3, 'FIFA24', 'Videogioco'),
(4, 'Monopoly', 'Giochi da tavaolo'),
(5, 'Lego', 'Costruzioni'),
(6, 'Risiko', 'Giochi da tavolo');


INSERT INTO Region (regionId, Name_Region) 
VALUES
(1, 'Italia'),
(2, 'USA'),
(3, 'Spain'),
(4, 'Cina');

INSERT INTO Sales (IdTransaction, ProductId, regionId, OrderData, UnitPrice) 
VALUES
(1, 1, 1, '2024-01-25', 10.50),
(2, 1, 2, '2024-02-14', 13.75),
(3, 2, 1, '2024-03-15', 20.00),
(4, 3, 2, '2024-03-20', 12.99),
(5, 4, 1, '2024-04-24', 18.50),
(6, 5, 4, '2024-04-30', 17.00),
(7, 6, 3, '2024-01-01', 12.99);


drop table Product;
drop table Region;
drop table Sales;

Select * from Product;
Select * from Region;
Select * from Sales;


-- 1. Verificare che i campi definiti come PK siano univoci. 

SELECT COUNT(*) AS NumProduct, COUNT(DISTINCT ProductId) AS productTot
FROM Product;
SELECT COUNT(*) AS NumRegion, COUNT(DISTINCT regionId) AS regionTot
FROM Region;
SELECT COUNT(*) AS NumSales, COUNT(DISTINCT IdTransaction) AS transactionsTot
FROM Sales;

-- 2. Esporre l'elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno:

SELECT p.Name_product, YEAR(s.OrderData) AS Anno, 
		SUM(s.UnitPrice) AS Fatturato_totale
FROM Product p
INNER JOIN Sales s
	ON p.ProductId = s.ProductId
GROUP BY p.Name_Product, YEAR(s.orderData);


-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente:

SELECT r.Name_Region,
		YEAR(s.OrderData) AS Anno,
		SUM(s.UnitPrice) AS Fatturato_totale
FROM Region r
INNER JOIN Sales s
	ON r.regionId = s.regionId
GROUP BY r.Name_Region, YEAR(s.OrderData)
ORDER BY YEAR(s.OrderData), SUM(s.UnitPrice) DESC;


-- 4.Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?

SELECT p.Category, 
		COUNT(s.IdTransaction) AS Num_transazioni
FROM Product p
LEFT JOIN Sales s 
	ON p.ProductId = s.ProductId
GROUP BY p.Category
ORDER BY Num_transazioni DESC
LIMIT 1;


-- 5.Quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.

SELECT p.Name_Product
FROM Product p
	LEFT JOIN Sales s 
	USING (ProductId)
WHERE s.IdTransaction IS NULL;

SELECT Name_Product
FROM Product
WHERE ProductId NOT IN (
						SELECT DISTINCT ProductId 
						FROM Sales);


-- 6.Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente):

SELECT COUNT(s.OrderData) AS Quantity, 
		p.Name_Product,
		p.Category, 
		MAX(s.OrderData) AS Ultima_data_vendita
FROM Product p
LEFT JOIN Sales s 
	USING (ProductId)
GROUP BY p.Name_Product, p.Category
ORDER BY MAX(s.OrderData) DESC;



